//place this file in the ki subdirectory
package ki;

public abstract class KeyedItem
{
	//create private instance variable of type Comparable
   private Comparable thekey;

   //constructor.. really need to finish this part!!!
   public KeyedItem(Comparable key) 
   {
	   thekey = key;
   }  

   public Comparable getKey() 
   {
	   return thekey;
   }   

   //Use Comparable's toString() method
   public String toString()
   {
      return thekey.toString();
   }
}